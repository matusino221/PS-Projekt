#!/bin/bash

rm throughput*
rm animation*
rm packetSize*
rm uzitocneData*
rm UzitocneData*
rm UzitoneNode.svg
rm ThroughputNodes.svg
rm ThroughputDatas.svg
