zadanie.sh -> bash skript: pusta zadanie.cc meni uzly, velkost prenasanych dat, vyratava odchylku, vykresluje grafy
uzly(11 22 33 44 55)
clear.sh ->  bash skript: vymaze vsekty vytvorene grafy pustit pred dalsim spustenim zadanie.sh
