# NS3
Zadanie v ns3 pre PS2
