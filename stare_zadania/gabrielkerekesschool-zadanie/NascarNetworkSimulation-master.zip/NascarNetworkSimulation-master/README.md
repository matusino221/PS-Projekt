# NascarNetworkSimulation
school assignment - ns3 network simulation
